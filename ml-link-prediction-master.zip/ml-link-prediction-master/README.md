Link prediction with Machine Learning Approach
![Screenshot](01.png)
![Screenshot](02.png)
![Screenshot](03.png)
